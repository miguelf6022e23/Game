import pygame
from pygame.locals import *
from textbox import *

def blkscreen(dispW,dispH,screenInfo,gameDisplay,clock):
    gameDisplay.fill((0,0,0))
    pygame.display.update()
    sf = shelve.open('misc1')
    textbox(dispW,dispH,screenInfo,gameDisplay,clock,sf,'blkScrn')
